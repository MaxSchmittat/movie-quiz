const quizContainer = document.getElementById('quiz-container'); //@ts-ignore
const questionContainer = document.getElementById('question-container'); //@ts-ignore
const answerButtons = document.getElementById('answer-buttons'); //@ts-ignore
const resultContainer = document.getElementById('result-container'); //@ts-ignore
const resultText = document.getElementById('result-text'); //@ts-ignore
const retryButton = document.getElementById('retry-button'); //@ts-ignore

let currentQuestionIndex = 0;

const questions = [
    {
        question: "Aus welchem Film stammt folgendes Zitat? Möge die Macht mit dir sein.",
        answers: ["Star Wars", "Star Trek", "The Matrix"],
        correctIndex: 0
    },
    {
        question: "Aus welchem Film stammt folgendes Zitat? Was ist das? Blaues Licht. Was macht das? Es leuchtet blau.",
        answers: ["Rambo 1", "Rambo 2", "Rambo 3"],
        correctIndex: 1
    },
    {
        question: "Aus welchem Film stammt folgendes Zitat? Ich bin Amerikaner, Süße, unsere Namen bedeuten einen Scheiß.",
        answers: ["Hangover", "Pulp Fiction", "Caddyshack"],
        correctIndex: 1
    },
];

// Event listener for answer button clicks
function selectAnswer(index) {
    if (index === questions[currentQuestionIndex].correctIndex) {
        // Correct answer
        currentQuestionIndex++;
        if (currentQuestionIndex < questions.length) {
            setNextQuestion();
        } else {
            endGame(true);
        }
    } else {
        // Incorrect answer
        endGame(false);
    }
}

// Set up the next question
function setNextQuestion() {
    resetState();
    showQuestion(questions[currentQuestionIndex]);
}

// Display the question and answer buttons
function showQuestion(question) {
    questionContainer.innerText = question.question;
    question.answers.forEach((answer, index) => {
        const button = document.createElement('button');
        button.innerText = answer;
        button.classList.add('btn');
        button.addEventListener('click', () => selectAnswer(index));
        answerButtons.appendChild(button);
    });
}

// Reset the state for the next question
function resetState() {
    while (answerButtons.firstChild) {
        answerButtons.removeChild(answerButtons.firstChild);
    }
}

// End the game and display the result
function endGame(isWinner) {
    if (isWinner) {
        resultText.innerText = "You're a Winner!";
    } else {
        resultText.innerText = "You Lost!";
    }
    resultContainer.classList.remove('hidden');
}

// Event listener for the retry button
function startGame() {
    currentQuestionIndex = 0;
    resultContainer.classList.add('hidden');
    setNextQuestion();
}

// Start the game initially
startGame();
